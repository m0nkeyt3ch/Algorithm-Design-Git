package com.example.rbgame;

public final class BuildConfig {
    public static final boolean DEBUG = true;
}
