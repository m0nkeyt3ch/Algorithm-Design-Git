package com.example.rbgame;

public final class R {

    public static final class attr {
    }

    public static final class dimen {
        public static final int activity_horizontal_margin = 2130968576;
        public static final int activity_vertical_margin = 2130968577;
    }

    public static final class drawable {
        public static final int boxblue = 2130837504;
        public static final int boxgreen = 2130837505;
        public static final int dot1 = 2130837506;
        public static final int dot2 = 2130837507;
        public static final int dot3 = 2130837508;
        public static final int fire1 = 2130837509;
        public static final int fire2 = 2130837510;
        public static final int ic_launcher = 2130837511;
        public static final int lock1 = 2130837512;
        public static final int lock2 = 2130837513;
        public static final int lock3 = 2130837514;
        public static final int match = 2130837515;
        public static final int p1 = 2130837516;
        public static final int p2 = 2130837517;
        public static final int p3 = 2130837518;
        public static final int p4 = 2130837519;
        public static final int redstar = 2130837520;
        public static final int yellowstar = 2130837521;
    }

    public static final class id {
        public static final int action_settings = 2131230733;
        public static final int buttonHelp = 2131230731;
        public static final int buttonPlay = 2131230732;
        public static final int buttonUpload = 2131230730;
        public static final int editschool = 2131230727;
        public static final int imageView1 = 2131230722;
        public static final int textID = 2131230726;
        public static final int textIP = 2131230729;
        public static final int textView0 = 2131230723;
        public static final int textView2 = 2131230725;
        public static final int textView3 = 2131230728;
        public static final int textchoose1 = 2131230724;
        public static final int viewChoose1 = 2131230720;
        public static final int viewGame1 = 2131230721;
    }

    public static final class layout {
        public static final int activity_choose = 2130903040;
        public static final int activity_game = 2130903041;
        public static final int activity_help = 2130903042;
        public static final int activity_welcome = 2130903043;
        public static final int choose = 2130903044;
    }

    public static final class menu {
        public static final int choose = 2131165184;
        public static final int game = 2131165185;
        public static final int help = 2131165186;
        public static final int welcome = 2131165187;
    }

    public static final class string {
        public static final int action_settings = 2131034113;
        public static final int app_name = 2131034112;
        public static final int hello_world = 2131034114;
        public static final int title_activity_choose = 2131034116;
        public static final int title_activity_game = 2131034117;
        public static final int title_activity_help = 2131034115;
    }

    public static final class style {
        public static final int AppBaseTheme = 2131099648;
        public static final int AppTheme = 2131099649;
    }
}
