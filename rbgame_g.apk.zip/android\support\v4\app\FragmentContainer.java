package android.support.v4.app;

import android.view.View;

/* compiled from: FragmentManager */
interface FragmentContainer {
    View findViewById(int i);
}
